import { useMutation, useQueryClient } from '@tanstack/react-query'
import { deleteTodo, setCompleted, type Todo } from './api'

export function TodoRow({ todo }: { todo: Todo }) {
  const client = useQueryClient()

  const toggle = useMutation({
    mutationFn: () => setCompleted(todo.id, !todo.completed),
    onSuccess: (updated) =>
      client.setQueryData<Todo[]>(['todos'], (old = []) => old.map((t) => (t.id === updated.id ? updated : t))),
  })
  const remove = useMutation({
    mutationFn: () => deleteTodo(todo.id),
    onSuccess: () => client.setQueryData<Todo[]>(['todos'], (old = []) => old.filter((t) => t.id !== todo.id)),
  })

  return (
    <li className={`row${todo.completed ? ' done' : ''}`}>
      <input
        type="checkbox"
        className="check"
        checked={todo.completed}
        disabled={toggle.isPending}
        onChange={() => toggle.mutate()}
        aria-label={todo.title}
      />
      <span className="title">{todo.title}</span>
      <button
        type="button"
        className="delete"
        disabled={remove.isPending}
        onClick={() => remove.mutate()}
        aria-label={`Delete ${todo.title}`}
      >
        <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
          <path d="M3 3l10 10M13 3L3 13" stroke="currentColor" strokeWidth="2" fill="none" />
        </svg>
      </button>
      {(toggle.isError || remove.isError) && (
        <p role="alert" className="message row-message">
          Couldn't save, try again
        </p>
      )}
    </li>
  )
}
