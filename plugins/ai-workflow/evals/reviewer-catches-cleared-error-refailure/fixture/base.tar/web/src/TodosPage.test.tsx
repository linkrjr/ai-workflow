import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { TodosPage } from './TodosPage'
import type { Todo } from './api'

const todo = (id: number, title: string, completed = false): Todo => ({
  id,
  title,
  completed,
  createdAt: '2026-11-09T12:00:00.000Z',
})

const json = (body: unknown, status = 200) =>
  Promise.resolve(new Response(JSON.stringify(body), { status }))

const fetchMock = vi.fn()

function renderPage() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={client}>
      <TodosPage />
    </QueryClientProvider>,
  )
}

const posts = () => fetchMock.mock.calls.filter(([, init]) => init?.method === 'POST')

beforeEach(() => {
  fetchMock.mockReset()
  vi.stubGlobal('fetch', fetchMock)
})

describe('list states', () => {
  it('AC10: shows a loading indicator while the list loads', () => {
    fetchMock.mockReturnValue(new Promise(() => {}))
    renderPage()
    expect(screen.getByRole('status')).toHaveTextContent('Loading todos')
  })

  it('AC9: shows "No todos yet" when the list is empty', async () => {
    fetchMock.mockReturnValue(json([]))
    renderPage()
    expect(await screen.findByText('No todos yet')).toBeInTheDocument()
  })

  it('AC7: lists todos in the order the API returns them, with completed state', async () => {
    fetchMock.mockReturnValue(json([todo(2, 'Second', true), todo(1, 'First')]))
    renderPage()
    const boxes = await screen.findAllByRole('checkbox')
    expect(screen.getAllByRole('listitem').map((li) => li.textContent)).toEqual(['Second', 'First'])
    expect(boxes[0]).toBeChecked()
    expect(boxes[1]).not.toBeChecked()
  })

  it('AC11: shows an error with Retry that loads the list again', async () => {
    fetchMock.mockReturnValueOnce(json({ error: 'boom' }, 500))
    renderPage()
    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't load todos")

    fetchMock.mockReturnValueOnce(json([todo(1, 'Back')]))
    await userEvent.click(screen.getByRole('button', { name: 'Retry' }))
    expect(await screen.findByText('Back')).toBeInTheDocument()
  })
})

describe('add form', () => {
  const input = () => screen.getByPlaceholderText('What needs doing?')

  async function ready(initial: Todo[] = [todo(1, 'Existing')]) {
    fetchMock.mockReturnValueOnce(json(initial))
    renderPage()
    await screen.findByPlaceholderText('What needs doing?')
    await waitFor(() => expect(screen.queryByRole('status')).not.toBeInTheDocument())
  }

  it('AC1/AC4: Enter adds the trimmed title at the top and clears the input', async () => {
    await ready()
    fetchMock.mockReturnValueOnce(json(todo(2, 'Buy milk'), 201))
    await userEvent.type(input(), '  Buy milk  {Enter}')

    const items = await screen.findAllByRole('listitem')
    expect(items.map((li) => li.textContent)).toEqual(['Buy milk', 'Existing'])
    expect(screen.getAllByRole('checkbox')[0]).not.toBeChecked()
    expect(input()).toHaveValue('')
    expect(JSON.parse(posts()[0][1].body)).toEqual({ title: 'Buy milk' })
  })

  it('AC1: the Add button adds the todo', async () => {
    await ready([])
    fetchMock.mockReturnValueOnce(json(todo(1, 'Walk dog'), 201))
    await userEvent.type(input(), 'Walk dog')
    await userEvent.click(screen.getByRole('button', { name: 'Add' }))
    expect(await screen.findByText('Walk dog')).toBeInTheDocument()
    expect(screen.queryByText('No todos yet')).not.toBeInTheDocument()
  })

  it.each(['', '   '])('AC2: rejects %j with a message and sends no request', async (text) => {
    await ready()
    if (text) await userEvent.type(input(), text)
    await userEvent.click(screen.getByRole('button', { name: 'Add' }))
    expect(screen.getByRole('alert')).toHaveTextContent('Enter a title')
    expect(input()).toHaveAttribute('aria-invalid', 'true')
    expect(posts()).toHaveLength(0)
  })

  it('AC3: rejects 201 characters, accepts exactly 200 (after trim)', async () => {
    await ready()
    await userEvent.click(input())
    await userEvent.paste('a'.repeat(201))
    await userEvent.keyboard('{Enter}')
    expect(screen.getByRole('alert')).toHaveTextContent('Max 200 characters')
    expect(posts()).toHaveLength(0)

    await userEvent.clear(input())
    fetchMock.mockReturnValueOnce(json(todo(2, 'a'.repeat(200)), 201))
    await userEvent.paste(` ${'a'.repeat(200)} `)
    await userEvent.keyboard('{Enter}')
    await waitFor(() => expect(posts()).toHaveLength(1))
    expect(JSON.parse(posts()[0][1].body).title).toHaveLength(200)
  })

  it('AC2: the validation message clears on the next keystroke', async () => {
    await ready()
    await userEvent.click(screen.getByRole('button', { name: 'Add' }))
    await userEvent.type(input(), 'x')
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  it('AC12: Add is disabled while saving', async () => {
    await ready()
    let finish!: (r: Response) => void
    fetchMock.mockReturnValueOnce(new Promise<Response>((r) => (finish = r)))
    await userEvent.type(input(), 'Slow{Enter}')
    expect(screen.getByRole('button', { name: /Add/ })).toBeDisabled()

    finish(new Response(JSON.stringify(todo(2, 'Slow')), { status: 201 }))
    await waitFor(() => expect(screen.getByRole('button', { name: 'Add' })).toBeEnabled())
  })

  it('AC12: on failure the list is unchanged, the input keeps its text, and the error clears on next success', async () => {
    await ready()
    fetchMock.mockReturnValueOnce(json({ error: 'x' }, 500))
    await userEvent.type(input(), 'Flaky{Enter}')

    expect(await screen.findByRole('alert')).toHaveTextContent("Couldn't save, try again")
    expect(input()).toHaveValue('Flaky')
    expect(screen.getAllByRole('listitem').map((li) => li.textContent)).toEqual(['Existing'])

    fetchMock.mockReturnValueOnce(json(todo(2, 'Flaky'), 201))
    await userEvent.type(input(), '{Enter}')
    await screen.findByText('Flaky')
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })
})

describe('toggle and delete', () => {
  const calls = (method: string) => fetchMock.mock.calls.filter(([, init]) => init?.method === method)

  async function ready(initial: Todo[]) {
    fetchMock.mockReturnValueOnce(json(initial))
    renderPage()
    await screen.findAllByRole('listitem')
  }

  const titles = () => screen.getAllByRole('listitem').map((li) => li.textContent)

  it('AC5: clicking the checkbox PATCHes completed and the row stays in place', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    fetchMock.mockReturnValueOnce(json(todo(2, 'Second', true)))
    await userEvent.click(screen.getByRole('checkbox', { name: 'Second' }))

    await waitFor(() => expect(screen.getByRole('checkbox', { name: 'Second' })).toBeChecked())
    expect(titles()).toEqual(['Second', 'First'])
    expect(calls('PATCH')[0][0]).toBe('/api/todos/2')
    expect(JSON.parse(calls('PATCH')[0][1].body)).toEqual({ completed: true })
  })

  it('AC5: clicking a completed checkbox sends completed false', async () => {
    await ready([todo(1, 'Done', true)])
    fetchMock.mockReturnValueOnce(json(todo(1, 'Done', false)))
    await userEvent.click(screen.getByRole('checkbox', { name: 'Done' }))

    await waitFor(() => expect(screen.getByRole('checkbox', { name: 'Done' })).not.toBeChecked())
    expect(JSON.parse(calls('PATCH')[0][1].body)).toEqual({ completed: false })
  })

  it('AC6: clicking delete removes the row immediately, with no confirmation', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    fetchMock.mockReturnValueOnce(Promise.resolve(new Response(null, { status: 204 })))
    await userEvent.click(screen.getByRole('button', { name: 'Delete Second' }))

    await waitFor(() => expect(titles()).toEqual(['First']))
    expect(calls('DELETE')[0][0]).toBe('/api/todos/2')
  })

  it('AC6/AC9: deleting the last todo shows the empty state', async () => {
    await ready([todo(1, 'Only')])
    fetchMock.mockReturnValueOnce(Promise.resolve(new Response(null, { status: 204 })))
    await userEvent.click(screen.getByRole('button', { name: 'Delete Only' }))
    expect(await screen.findByText('No todos yet')).toBeInTheDocument()
  })

  it('AC12: only the checkbox in use is disabled while the toggle saves', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    let finish!: (r: Response) => void
    fetchMock.mockReturnValueOnce(new Promise<Response>((r) => (finish = r)))
    await userEvent.click(screen.getByRole('checkbox', { name: 'Second' }))

    expect(screen.getByRole('checkbox', { name: 'Second' })).toBeDisabled()
    expect(screen.getByRole('checkbox', { name: 'First' })).toBeEnabled()
    expect(screen.getByRole('button', { name: 'Delete Second' })).toBeEnabled()

    finish(new Response(JSON.stringify(todo(2, 'Second', true)), { status: 200 }))
    await waitFor(() => expect(screen.getByRole('checkbox', { name: 'Second' })).toBeEnabled())
  })

  it('AC12: only the delete button in use is disabled while the delete saves', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    fetchMock.mockReturnValueOnce(new Promise(() => {}))
    await userEvent.click(screen.getByRole('button', { name: 'Delete Second' }))

    expect(screen.getByRole('button', { name: 'Delete Second' })).toBeDisabled()
    expect(screen.getByRole('button', { name: 'Delete First' })).toBeEnabled()
    expect(screen.getByRole('checkbox', { name: 'Second' })).toBeEnabled()
  })

  it('AC12: a failed toggle leaves the list as it was, shows an error under the row, and clears on next success', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    fetchMock.mockReturnValueOnce(json({ error: 'x' }, 500))
    await userEvent.click(screen.getByRole('checkbox', { name: 'Second' }))

    const row = screen.getByRole('checkbox', { name: 'Second' }).closest('li')!
    expect(await within(row).findByRole('alert')).toHaveTextContent("Couldn't save, try again")
    expect(screen.getByRole('checkbox', { name: 'Second' })).not.toBeChecked()
    expect(screen.getByRole('checkbox', { name: 'Second' })).toBeEnabled()
    expect(screen.getAllByRole('alert')).toHaveLength(1)

    fetchMock.mockReturnValueOnce(json(todo(2, 'Second', true)))
    await userEvent.click(screen.getByRole('checkbox', { name: 'Second' }))
    await waitFor(() => expect(screen.getByRole('checkbox', { name: 'Second' })).toBeChecked())
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  it('AC12/AC13: a failed delete (404) keeps the row and shows the error under it', async () => {
    await ready([todo(2, 'Second'), todo(1, 'First')])
    fetchMock.mockReturnValueOnce(json({ error: 'Not found' }, 404))
    await userEvent.click(screen.getByRole('button', { name: 'Delete Second' }))

    const row = screen.getByRole('checkbox', { name: 'Second' }).closest('li')!
    expect(await within(row).findByRole('alert')).toHaveTextContent("Couldn't save, try again")
    expect(screen.getByRole('button', { name: 'Delete Second' })).toBeEnabled()
    expect(screen.getAllByRole('listitem')).toHaveLength(2)
  })
})
