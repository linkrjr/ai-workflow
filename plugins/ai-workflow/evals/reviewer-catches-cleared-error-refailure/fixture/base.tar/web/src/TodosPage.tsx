import { useQuery } from '@tanstack/react-query'
import { AddForm } from './AddForm'
import { listTodos } from './api'
import { TodoRow } from './TodoRow'

export function TodosPage() {
  const todos = useQuery({ queryKey: ['todos'], queryFn: listTodos })

  return (
    <main className="page">
      <header className="brand">
        <span className="brand-mark" aria-hidden="true" />
        <h1>Todos</h1>
      </header>
      <AddForm />
      {todos.isPending ? (
        <div role="status" className="loading">
          <span className="spinner" aria-hidden="true" />
          <span>Loading todos</span>
          {[0, 1, 2].map((i) => (
            <div key={i} className="skeleton" aria-hidden="true" />
          ))}
        </div>
      ) : todos.isError ? (
        <div role="alert" className="load-error">
          <span>Couldn't load todos</span>
          <button type="button" className="retry" onClick={() => todos.refetch()}>
            Retry
          </button>
        </div>
      ) : todos.data.length === 0 ? (
        <p className="empty">No todos yet</p>
      ) : (
        <ul className="list">
          {todos.data.map((todo) => (
            <TodoRow key={todo.id} todo={todo} />
          ))}
        </ul>
      )}
    </main>
  )
}
