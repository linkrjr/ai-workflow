import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useRef, useState, type FormEvent } from 'react'
import { createTodo, type Todo } from './api'

const MAX = 200

export function AddForm() {
  const client = useQueryClient()
  const inputRef = useRef<HTMLInputElement>(null)
  const [value, setValue] = useState('')
  const [invalid, setInvalid] = useState<string | null>(null)

  const add = useMutation({
    mutationFn: createTodo,
    onSuccess: (todo) => {
      client.setQueryData<Todo[]>(['todos'], (old = []) => [todo, ...old])
      setValue('')
      inputRef.current?.focus()
    },
  })

  const message = invalid ?? (add.isError ? "Couldn't save, try again" : null)
  const length = value.trim().length

  function submit(e: FormEvent) {
    e.preventDefault()
    if (add.isPending) return
    const title = value.trim()
    if (!title) return setInvalid('Enter a title')
    if (title.length > MAX) return setInvalid(`Max ${MAX} characters`)
    add.mutate(title)
  }

  return (
    <form className="add-form" onSubmit={submit} noValidate>
      <div className="add-fields">
        <input
          ref={inputRef}
          className="add-input"
          placeholder="What needs doing?"
          aria-label="New todo"
          value={value}
          aria-invalid={message ? true : undefined}
          aria-describedby={message ? 'add-message' : undefined}
          onChange={(e) => {
            setValue(e.target.value)
            setInvalid(null)
          }}
        />
        <button type="submit" className="add-button" disabled={add.isPending}>
          {add.isPending && <span className="spinner" aria-hidden="true" />}
          Add
        </button>
      </div>
      <div className="add-meta">
        {message && (
          <p id="add-message" role="alert" className="message">
            {message}
          </p>
        )}
        {length >= 180 && <span className="counter">{length} / {MAX}</span>}
      </div>
    </form>
  )
}
