export type Todo = {
  id: number
  title: string
  completed: boolean
  createdAt: string
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init)
  if (!res.ok) throw new Error(`${res.status}`)
  return res.status === 204 ? (undefined as T) : res.json()
}

export const listTodos = () => request<Todo[]>('/api/todos')

export const createTodo = (title: string) =>
  request<Todo>('/api/todos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title }),
  })

export const setCompleted = (id: number, completed: boolean) =>
  request<Todo>(`/api/todos/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ completed }),
  })

export const deleteTodo = (id: number) => request<void>(`/api/todos/${id}`, { method: 'DELETE' })
